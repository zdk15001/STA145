# Set Working Directory
setwd("/courses/STA145/klinez")

# Install "haven" package
#install.packages("haven")

# Load "haven" package
library("haven")

# Load fifthgrader data
fifth_graders <- read.csv("fifth_graders.csv")
