# STEP 1: Generate your sample
sample(1:300, 30, replace = FALSE)
